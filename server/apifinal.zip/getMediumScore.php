<?php
    require "connect.php";
    $iduser=$_GET["iduser"];
    $page=$_GET["page"];
    $space=$page*30;
    $sql= "SELECT questions.level,questions.category,AVG(score) AS 'mediumscore',COUNT(score) AS 'count' FROM users_questions,questions WHERE iduser='$iduser' AND users_questions.idquestion=questions.idquestion GROUP BY users_questions.idquestion ORDER BY questions.category ASC,questions.level ASC LIMIT $space,30 ";

    class medium{
        function medium($level,$category,$mediumscore,$count){
            $this->level=$level;
            $this->category=$category;
            $this->mediumscore=$mediumscore;
            $this->count=$count;
        }
    }
    $array=array();
    $result= mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result)){
        array_push($array,new medium($row['level'],$row['category'],$row['mediumscore'],$row['count']));
    }

    echo json_encode($array);
    mysqli_close($con);