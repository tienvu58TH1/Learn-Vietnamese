<?php
    require "connect.php";
    $iduser=$_GET["iduser"];
    $category=$_GET["category"];
    $page=$_GET["page"];
    $space=$page*30;
    $sql= "SELECT questions.level,score,time FROM users_questions,questions WHERE users_questions.idquestion=questions.idquestion AND iduser='$iduser' AND questions.category='$category' ORDER BY questions.level ASC, time ASC LIMIT $space,30 ";

    class history{
        function history($level,$score,$time){
            $this->level=$level;
            $this->score=$score;
            $this->time=$time;

        }
    }
    $array=array();
    $result= mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result)){
        array_push($array,new history($row['level'],$row['score'],$row['time']));
    }

    echo json_encode($array);
    mysqli_close($con);