<?php
    require "connect.php";

    $sql= "select title,image,author,link,namecategory from tracks,categories WHERE tracks.idcategory=categories.idcategory";

    class Track{
        function Track($title,$image,$author,$namecategory,$link){
            $this->title=$title;
            $this->image=$image;
            $this->author=$author;
            $this->namecategory=$namecategory;
            $this->link=$link;

        }
    }
    $arrayTrack=array();
    $result= mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result)){
        array_push($arrayTrack,new Track($row['title'],$row['image'],$row['author'],$row['namecategory'],$row['link']));
    }
    
    echo json_encode($arrayTrack);
    mysqli_close($con);
?>