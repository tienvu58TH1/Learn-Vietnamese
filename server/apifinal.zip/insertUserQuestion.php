<?php
    require "connect.php";
    $iduser=$_POST["iduser"];
    $idquestion=$_POST["idquestion"];
    $score=$_POST["score"];
    $time=$_POST["time"];

    $sql="insert into users_questions(iduser,idquestion,score,time) values('$iduser','$idquestion','$score','$time')";
    if(mysqli_query($con,$sql)){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>