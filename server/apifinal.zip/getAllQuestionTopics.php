<?php
    require "connect.php";
    $page=$_GET["page"];
    $space=$page*30;
    $sql= "select * from questiontopics ORDER BY idtopic ASC, level ASC LIMIT $space,30 ";

    class questions{
        function questions($idquestiontopic,$level,$content,$translate,$idtopic){
            $this->idquestiontopic=$idquestiontopic;
            $this->level=$level;
            $this->content=$content;
            $this->translate=$translate;
            $this->idtopic=$idtopic;
        }
    }
    $arrayQuestion=array();
    $result= mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result)){
        array_push($arrayQuestion,new questions($row['idquestiontopic'],$row['level'],$row['content'],$row['translate'],$row['idtopic']));
    }
    echo json_encode($arrayQuestion);
    mysqli_close($con);
?>