<?php
    require "connect.php";
    $username=$_POST["username"];
    $name=$_POST["name"];

    $sql= "update users set name='$name' where username='$username'";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>