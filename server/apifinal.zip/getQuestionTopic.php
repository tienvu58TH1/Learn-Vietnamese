<?php
    require "connect.php";
    $idtopic=$_GET["idtopic"];
    $sql= "select * from questiontopics where idtopic=$idtopic ORDER BY level ASC ";

    class questions{
        function questions($idquestiontopic,$level,$content,$translate){
            $this->idquestiontopic=$idquestiontopic;
            $this->level=$level;
            $this->content=$content;
            $this->translate=$translate;
        }
    }
    $arrayQuestion=array();
    $result= mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result)){
        array_push($arrayQuestion,new questions($row['idquestiontopic'],$row['level'],$row['content'],$row['translate']));
    }
    
    echo json_encode($arrayQuestion);
    mysqli_close($con);
?>