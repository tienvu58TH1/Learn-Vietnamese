<?php
    require "connect.php";
    $idtopic=$_POST["idtopic"];
    $numbertopic=$_POST["numbertopic"];
    $titletopic=$_POST["titletopic"];
    $category=$_POST["category"];
    $sql= "UPDATE topics SET numbertopic='$numbertopic',titletopic='$titletopic',category='$category' WHERE idtopic='$idtopic'";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>