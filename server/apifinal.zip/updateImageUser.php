<?php
    require "connect.php";
    $username=$_POST["username"];
    $image=$_POST["image"];
    $imageuser= "image_user/$username.jpg";

    file_put_contents($imageuser,base64_decode($image));
    $status="ok";
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>