<?php
    require "connect.php";
    $category=$_GET["category"];
    $sql= "select idquestion,level,content,scorepass,category from questions where category=$category ORDER BY level ASC ";

    class questions{
        function questions($idquestion,$level,$content,$scorepass,$category){
            $this->idquestion=$idquestion;
            $this->level=$level;
            $this->content=$content;
            $this->scorepass=$scorepass;
            $this->category=$category;

        }
    }
    $arrayTrack=array();
    $result= mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result)){
        array_push($arrayTrack,new questions($row['idquestion'],$row['level'],$row['content'],$row['scorepass'],$row['category']));
    }
    
    echo json_encode($arrayTrack);
    mysqli_close($con);
?>