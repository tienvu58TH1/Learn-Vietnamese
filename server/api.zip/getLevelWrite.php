<?php
    require "connect.php";
    $username=$_GET["username"];
    $sql= "select listeninglevel from users where username='$username' ";

    $result= mysqli_query($con,$sql);
    if(mysqli_num_rows($result)>0){
        $row=mysqli_fetch_assoc($result);
        $status="ok";
        $levelwrite=$row['listeninglevel'];
    }else{
        $status="error";
        $levelwrite=0;
    }
    echo json_encode(array("response"=>$status,"levelwrite"=>$levelwrite));
    mysqli_close($con);
?>