<?php
    require "connect.php";
    $sql= "select * from topics ORDER BY category ASC,numbertopic ASC ";

    class Topic{
        function Topic($idtopic,$numbertopic,$titletopic,$category){
            $this->idtopic=$idtopic;
            $this->numbertopic=$numbertopic;
            $this->titletopic=$titletopic;
            $this->category=$category;
        }
    }
    $arrayTopic=array();
    $result= mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result)){
        array_push($arrayTopic,new Topic($row['idtopic'],$row['numbertopic'],$row['titletopic'],$row['category']));
    }
    echo json_encode($arrayTopic);
    mysqli_close($con);
?>