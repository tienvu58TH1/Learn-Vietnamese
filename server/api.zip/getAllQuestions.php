<?php
    require "connect.php";
    $page=$_GET["page"];
    $space=$page*30;
    $sql= "select idquestion,level,content,scorepass,category from questions ORDER BY category ASC, level ASC LIMIT $space,30 ";

    class questions{
        function questions($idquestion,$level,$content,$scorepass,$category){
            $this->idquestion=$idquestion;
            $this->level=$level;
            $this->content=$content;
            $this->scorepass=$scorepass;
            $this->category=$category;

        }
    }
    $arrayQuestion=array();
    $result= mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result)){
        array_push($arrayQuestion,new questions($row['idquestion'],$row['level'],$row['content'],$row['scorepass'],$row['category']));
    }
    
    echo json_encode($arrayQuestion);
    mysqli_close($con);
?>