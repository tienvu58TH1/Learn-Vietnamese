<?php
    require "connect.php";
    $category=$_GET["category"];
    $sql= "select * from topics where category='$category' ORDER BY numbertopic ASC ";

    class Topic{
        function Topic($idtopic,$numbertopic,$titletopic){
            $this->idtopic=$idtopic;
            $this->numbertopic=$numbertopic;
            $this->titletopic=$titletopic;

        }
    }
    $arrayTopic=array();
    $result= mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result)){
        array_push($arrayTopic,new Topic($row['idtopic'],$row['numbertopic'],$row['titletopic']));
    }
    echo json_encode($arrayTopic);
    mysqli_close($con);
?>