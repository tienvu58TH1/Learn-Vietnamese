<?php
    require "connect.php";
    $level=$_POST["level"];
    $idtopic=$_POST["idtopic"];
    $content=$_POST["content"];
    $translate=$_POST["translate"];

    $sql= "INSERT INTO questiontopics(content,translate, level, idtopic) VALUES ('$content','$translate','$level',$idtopic)";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>