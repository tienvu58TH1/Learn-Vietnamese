<?php
    require "connect.php";
    $username=$_POST["username"];
    $password=$_POST["password"];

    $sql= "select * from users where username= '$username' and password='$password'";
    $result= mysqli_query($con,$sql);
    if(!mysqli_num_rows($result)>0){
        $status="failed";
        echo json_encode(array("response"=>$status));
    }else{
        $row= mysqli_fetch_assoc($result);
        $iduser=$row['iduser'];
        $name=$row['name'];
        $imageuser=$row['imageuser'];
        $checkadmin=$row['checkadmin'];
        $levelspeech=$row['speakinglevel'];
        $levelwrite=$row['listeninglevel'];
        $phone=$row['phone'];
        $email=$row['email'];
        $status="ok";
        echo json_encode(array("response"=>$status,"iduser"=>$iduser,"name"=>$name,"imageuser"=>$imageuser,"phone"=>$phone,"email"=>$email,"levelwrite"=>$levelwrite,"levelspeech"=>$levelspeech,"checkadmin"=>$checkadmin));
    }
    mysqli_close($con);
?>