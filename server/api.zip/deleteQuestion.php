<?php
    require "connect.php";
    $idquestion=$_POST["idquestion"];
    $sql= "DELETE FROM questions WHERE idquestion='$idquestion'";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>