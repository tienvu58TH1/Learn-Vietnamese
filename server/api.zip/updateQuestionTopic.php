<?php
    require "connect.php";
    $idquestiontopic=$_POST["idquestiontopic"];
    $level=$_POST["level"];
    $idtopic=$_POST["idtopic"];
    $content=$_POST["content"];
    $translate=$_POST["translate"];

    $sql= "UPDATE questiontopics SET content='$content',level='$level',idtopic='$idtopic',translate='$translate'
    WHERE idquestiontopic='$idquestiontopic'";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>