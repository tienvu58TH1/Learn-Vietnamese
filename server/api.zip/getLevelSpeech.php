<?php
    require "connect.php";
    $username=$_GET["username"];
    $sql= "select speakinglevel from users where username='$username' ";

    $result= mysqli_query($con,$sql);
    if(mysqli_num_rows($result)>0){
        $row=mysqli_fetch_assoc($result);
        $status="ok";
        $levelspeech=$row['speakinglevel'];
    }else{
        $status="error";
        $levelspeech=0;
    }
    echo json_encode(array("response"=>$status,"levelspeech"=>$levelspeech));
    mysqli_close($con);
?>