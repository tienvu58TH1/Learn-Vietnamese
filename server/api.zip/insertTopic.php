<?php
    require "connect.php";
    $numbertopic=$_POST["numbertopic"];
    $titletopic=$_POST["titletopic"];
    $category=$_POST["category"];

    $sql= "INSERT INTO topics(numbertopic, titletopic, category) VALUES('$numbertopic','$titletopic',$category)";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>