<?php
    require "connect.php";
    $sql= "SELECT name,imageuser,listeninglevel FROM users ORDER BY listeninglevel DESC LIMIT 0,10 ";

    class user{
        function user($levelwrite,$name,$imageuser){
            $this->levelwrite=$levelwrite;
            $this->name=$name;
            $this->imageuser=$imageuser;

        }
    }
    $arrayUser=array();
    $result= mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result)){
        array_push($arrayUser,new user($row['listeninglevel'],$row['name'],$row['imageuser']));
    }
    
    echo json_encode($arrayUser);
    mysqli_close($con);
?>