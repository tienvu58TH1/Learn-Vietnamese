<?php
    require "connect.php";
    $name=$_POST["name"];
    $username=$_POST["username"];
    $password=$_POST["password"];
    $image=$_POST['image'];
    $imageuser= "image_user/$username.jpg";

    $sql= "select * from users where username= '$username'";
    $result= mysqli_query($con,$sql);
    if(mysqli_num_rows($result)>0){
        $status="exits";
    }else{
        $sql="insert into users(name,username,password,imageuser,speakinglevel,listeninglevel,checkadmin) values('$name','$username','$password','https://tienvu1305.000webhostapp.com/$imageuser',1,1,0);";
        if(mysqli_query($con,$sql)){
            $status="ok";
            file_put_contents($imageuser,base64_decode($image));
        }else{
            $status="error";
        }
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>