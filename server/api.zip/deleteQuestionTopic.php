<?php
    require "connect.php";
    $idquestiontopic=$_POST["idquestiontopic"];
    $sql= "DELETE FROM questiontopics WHERE idquestiontopic='$idquestiontopic'";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>