<?php
    require "connect.php";
    $username=$_POST["username"];
    $levelspeech=$_POST["levelspeech"];

    $sql= "update users set speakinglevel='$levelspeech' where username='$username'";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>