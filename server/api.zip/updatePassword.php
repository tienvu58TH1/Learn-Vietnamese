<?php
    require "connect.php";
    $username=$_POST["username"];
    $password=$_POST["password"];
    $newpassword=$_POST["newpassword"];

    $sql= "update users set password='$newpassword' where username='$username' and password='$password'";
    $result= mysqli_query($con,$sql);
    if($result){
        $sql="select * from users where username='$username' and password='$newpassword'";
        $result= mysqli_query($con,$sql);
        if(mysqli_num_rows($result)>0){
            $status="ok";
        }else{
            $status="failed";
        }
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>