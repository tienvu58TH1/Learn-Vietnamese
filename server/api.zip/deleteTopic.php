<?php
    require "connect.php";
    $idtopic=$_POST["idtopic"];
    $sql= "DELETE FROM topics WHERE idtopic='$idtopic'";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>