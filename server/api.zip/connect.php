<?php
$host="localhost";
$username="id14850335_tienvu";
$password="BYc8K4A-xCdXFVn";
$dbname="id14850335_userdb";
$con = mysqli_connect($host,$username,$password,$dbname);
if($con){
}else{
    echo"connection failed";
}
?>