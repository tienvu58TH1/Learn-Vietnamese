<?php
    require "connect.php";
    $level=$_POST["level"];
    $category=$_POST["category"];
    $scorepass=$_POST["scorepass"];
    $content=$_POST["content"];

    $sql= "INSERT INTO questions(content, level, category, scorepass) VALUES ('$content','$level',$category,$scorepass)";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>