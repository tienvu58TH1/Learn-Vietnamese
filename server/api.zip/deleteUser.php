<?php
    require "connect.php";
    $username=$_POST["username"];
    $sql= "DELETE FROM users WHERE username='$username'";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>