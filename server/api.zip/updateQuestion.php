<?php
    require "connect.php";
    $idquestion=$_POST["idquestion"];
    $level=$_POST["level"];
    $category=$_POST["category"];
    $scorepass=$_POST["scorepass"];
    $content=$_POST["content"];

    $sql= "UPDATE questions SET content='$content',level='$level',category='$category',scorepass='$scorepass' WHERE idquestion='$idquestion'";
    $result= mysqli_query($con,$sql);
    if($result){
        $status="ok";
    }else{
        $status="error";
    }
    echo json_encode(array("response"=>$status));
    mysqli_close($con);
?>