<?php
    require "connect.php";

    $sql= "select * from users";

    class User{
        function User($iduser,$name,$username,$password,$imageuser,$levelspeech,$levelwrite){
            $this->iduser=$iduser;
            $this->name=$name;
            $this->username=$username;
            $this->password=$password;
            $this->imageuser=$imageuser;
            $this->levelspeech=$levelspeech;
            $this->levelwrite=$levelwrite;
        }
    }
    $arrayUser=array();
    $result= mysqli_query($con,$sql);
    while($row=mysqli_fetch_assoc($result)){
        array_push($arrayUser,new User($row['iduser'],$row['name'],$row['username'],$row['password'],$row['imageuser'],$row['levelspeech'],$row['levelwrite']));
    }
    echo json_encode($arrayUser);
    mysqli_close($con);
?>